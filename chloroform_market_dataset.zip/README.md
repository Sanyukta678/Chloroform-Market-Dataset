# Chloroform Market Dataset (IC3572)

This repository contains structured dataset files extracted from the publicly available summary of the Chloroform Market report by NextMSC.

## Files Included
- market_overview.csv
- segmentation.csv
- metadata.json
- README.md

## Notes
This dataset includes *only* publicly available summary data and no proprietary report content.
